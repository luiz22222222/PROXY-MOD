# PROXY MOD — projeto Android

Projeto Android Studio em Java para Moto G84 / Android.

## O que funciona
- APK independente com painel PROXY MOD.
- Botão ATIVAR/DESATIVAR AUXÍLIO DE MIRA.
- Simulador interno: a assistência suaviza e limita a aproximação da mira ao alvo nesta tela.
- Botão para abrir o Free Fire normal (`com.dts.freefireth`), se instalado.

## Limite importante
A assistência é exclusiva do simulador interno. O app não lê a tela do Free Fire, não injeta código, não altera controles do jogo e não oferece anti-ban.

## Como gerar o APK
1. Extraia o ZIP.
2. Abra a pasta `ProxyModProject` no Android Studio.
3. Aguarde a sincronização do Gradle.
4. Selecione Build > Build Bundle(s) / APK(s) > Build APK(s).
5. O APK de teste será criado em `app/build/outputs/apk/debug/app-debug.apk`.

Requisitos: Android Studio com Android SDK 35 e JDK 17.
