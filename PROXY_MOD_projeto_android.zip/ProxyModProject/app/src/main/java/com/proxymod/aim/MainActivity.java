package com.proxymod.aim;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Color;
import android.view.View;
import android.widget.*;
import android.graphics.Typeface;
import android.view.Gravity;
import android.graphics.drawable.GradientDrawable;

public class MainActivity extends Activity {
    private AimDemoView demo;
    private boolean enabled = false;
    private TextView status, toggle;
    private int purple = Color.rgb(181,108,255);

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(22), dp(34), dp(22), dp(20));
        page.setBackgroundColor(Color.rgb(16,13,24));

        TextView brand = new TextView(this);
        brand.setText("PROXY MOD");
        brand.setTextColor(purple);
        brand.setTextSize(28);
        brand.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        brand.setGravity(Gravity.CENTER);
        page.addView(brand);

        TextView sub = new TextView(this);
        sub.setText("AUXÍLIO DE MIRA  •  TREINAMENTO");
        sub.setTextColor(Color.LTGRAY);
        sub.setGravity(Gravity.CENTER);
        sub.setPadding(0, dp(5), 0, dp(20));
        page.addView(sub);

        status = new TextView(this);
        status.setText("STATUS: DESATIVADO");
        status.setTextColor(Color.LTGRAY);
        status.setGravity(Gravity.CENTER);
        page.addView(status);

        toggle = new TextView(this);
        toggle.setText("ATIVAR AUXÍLIO DE MIRA");
        toggle.setTextColor(Color.WHITE);
        toggle.setTextSize(16);
        toggle.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        toggle.setGravity(Gravity.CENTER);
        toggle.setPadding(dp(12), dp(16), dp(12), dp(16));
        toggle.setBackground(bg(Color.rgb(112,54,170), dp(14)));
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1, -2);
        bp.topMargin = dp(14);
        page.addView(toggle, bp);
        toggle.setOnClickListener(v -> {
            enabled = !enabled;
            demo.setAssistEnabled(enabled);
            status.setText(enabled ? "STATUS: ATIVADO NO SIMULADOR" : "STATUS: DESATIVADO");
            toggle.setText(enabled ? "DESATIVAR AUXÍLIO DE MIRA" : "ATIVAR AUXÍLIO DE MIRA");
            toggle.setBackground(bg(enabled ? Color.rgb(150,55,75) : Color.rgb(112,54,170), dp(14)));
        });

        TextView hint = new TextView(this);
        hint.setText("Demonstração: a assistência suaviza a aproximação da mira ao alvo dentro desta tela. Não altera a mira de outros jogos.");
        hint.setTextColor(Color.rgb(190,180,205));
        hint.setTextSize(12);
        hint.setPadding(2, dp(12), 2, dp(8));
        page.addView(hint);

        demo = new AimDemoView(this);
        LinearLayout.LayoutParams vp = new LinearLayout.LayoutParams(-1, 0, 1);
        vp.topMargin = dp(8);
        page.addView(demo, vp);

        TextView launch = new TextView(this);
        launch.setText("ABRIR FREE FIRE NORMAL");
        launch.setTextColor(Color.WHITE);
        launch.setTextSize(14);
        launch.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        launch.setGravity(Gravity.CENTER);
        launch.setPadding(dp(10), dp(15), dp(10), dp(15));
        launch.setBackground(bg(Color.rgb(53,45,68), dp(14)));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dp(12);
        page.addView(launch, lp);
        launch.setOnClickListener(v -> openFreeFire());

        setContentView(page);
    }

    private void openFreeFire() {
        Intent i = getPackageManager().getLaunchIntentForPackage("com.dts.freefireth");
        if (i != null) startActivity(i);
        else Toast.makeText(this, "Free Fire normal não foi encontrado neste aparelho.", Toast.LENGTH_LONG).show();
    }
    private GradientDrawable bg(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color); d.setCornerRadius(radius); return d;
    }
    private int dp(int v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }

    static class AimDemoView extends View {
        Paint p = new Paint(3);
        boolean assist = false;
        float aimX = 0, aimY = 0, targetX = 0, targetY = 0;
        boolean initialized = false;
        AimDemoView(Activity c) { super(c); setBackgroundColor(Color.rgb(28,23,38)); }
        void setAssistEnabled(boolean value) { assist = value; invalidate(); }
        @Override protected void onDraw(Canvas c) {
            super.onDraw(c);
            float w=getWidth(), h=getHeight();
            if (!initialized) { aimX=w*.5f; aimY=h*.72f; targetX=w*.5f; targetY=h*.30f; initialized=true; }
            p.setColor(Color.rgb(90,75,110)); p.setStrokeWidth(2); p.setStyle(Paint.Style.STROKE);
            c.drawCircle(targetX,targetY,34,p);
            p.setColor(Color.rgb(255,190,90)); p.setStyle(Paint.Style.FILL);
            c.drawCircle(targetX,targetY,5,p);
            p.setColor(Color.WHITE); p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(2);
            c.drawCircle(aimX,aimY,17,p);
            c.drawLine(aimX-26,aimY,aimX+26,aimY,p);
            c.drawLine(aimX,aimY-26,aimX,aimY+26,p);
            p.setStyle(Paint.Style.FILL); p.setTextSize(12);
            p.setColor(Color.LTGRAY);
            c.drawText(assist ? "ASSISTÊNCIA: LIGADA (SIMULAÇÃO)" : "TOQUE PARA MOVER A MIRA", 14, h-18, p);
            if (assist) {
                // Gentle capped interpolation for this self-contained demo only.
                float dx=targetX-aimX, dy=targetY-aimY;
                aimX += Math.max(-5, Math.min(5, dx*0.08f));
                aimY += Math.max(-5, Math.min(5, dy*0.08f));
                postInvalidateDelayed(16);
            }
        }
        @Override public boolean onTouchEvent(android.view.MotionEvent e) {
            if (e.getAction()==android.view.MotionEvent.ACTION_DOWN || e.getAction()==android.view.MotionEvent.ACTION_MOVE) {
                if (!assist) { aimX=e.getX(); aimY=e.getY(); invalidate(); }
                return true;
            }
            return true;
        }
    }
}
